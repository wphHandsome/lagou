import Demo from '../demo';
import { snapshotDemo } from '../../../test/demo';

snapshotDemo(Demo);
