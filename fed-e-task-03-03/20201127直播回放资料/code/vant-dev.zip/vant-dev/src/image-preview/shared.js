import { createNamespace } from '../utils';

const [createComponent, bem] = createNamespace('image-preview');

export { createComponent, bem };
