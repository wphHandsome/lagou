const babelConfig = require('./lib/config/babel.config');

module.exports = api => babelConfig(api);
