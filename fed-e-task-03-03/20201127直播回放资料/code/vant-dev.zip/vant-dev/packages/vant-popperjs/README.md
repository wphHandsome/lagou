# @vant/popperjs

@popperjs/core in commonjs format, added Object.assign polyfill.

## Install

```shell
yarn add @vant/popperjs
```

## Usage

see: https://popper.js.org/

## Refer

issue: https://github.com/youzan/vant/issues/7626
