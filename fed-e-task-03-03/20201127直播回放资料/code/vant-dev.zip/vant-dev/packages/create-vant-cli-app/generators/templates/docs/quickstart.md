# 快速上手

### 安装

```bash
# 通过 npm 安装
npm i <%= name %> -S

# 通过 yarn 安装
yarn add <%= name %>
```
