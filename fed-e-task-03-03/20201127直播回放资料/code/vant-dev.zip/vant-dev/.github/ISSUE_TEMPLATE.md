你好，请使用下面的链接创建 issue 以帮助我们更快的排查问题，不规范的 issue 会被关闭，感谢配合。

http://vant-contrib.gitee.io/vant-issue-generater

---

Please use the link below to create a new issue, the non-standard issue will be closed.

https://youzan.github.io/vant-issue-generater
