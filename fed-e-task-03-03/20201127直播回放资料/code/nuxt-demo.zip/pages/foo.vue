<template>
  <div>
    <button @click="$router.push('/')">Go Home</button>
    <h1>Foo Page</h1>
  </div>
</template>

<script>
export default {
  name: 'FooPage'
}
</script>

<style>

</style>
