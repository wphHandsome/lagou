<template>
  <div>
    <h1>Hello World!</h1>
    <nuxt-link to="/foo">Go Foo</nuxt-link>
    <h2>文章列表</h2>
    <ul>
      <li v-for="post in posts" :key="post.id">
        <nuxt-link :to="`/posts/${post.id}`">{{ post.title }}</nuxt-link>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Home',
  // 如果页面中有动态数据（需要通过接口展示的）
  // 如果想要让该数据能够从服务端渲染出来，则写到 asyncData 中
  data () {
    return {
      foo: 'bar',
      posts: []
    }
  },

  // 首屏访问在服务端执行
  // 如果是客户端交互访问，则在客户端执行
  // async asyncData () {
  //   const { data } = await axios.get('https://jsonplaceholder.typicode.com/posts')

  //   // 把数据放到对象中返回，该数据会和 data 中的数据合并到一起
  //   return {
  //     posts: data
  //   }
  // },

  // 如果你只想在客户端渲染动态数据
  async mounted () {
    const { data } = await axios.get('https://jsonplaceholder.typicode.com/posts')
    this.posts = data
  }
}
</script>
