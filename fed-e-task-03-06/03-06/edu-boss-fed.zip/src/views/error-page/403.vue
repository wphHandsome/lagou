<template>
  <div class="403">
    <h1>403 Not Permission.</h1>
  </div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'NotPermission'
})
</script>
